# DirectoPy
Simpe file manager on Python and PyQt5
<br>
![Main window](/docs/images/FileManagerScreenshot.png)

**Current features:**
- View and edit files
- Build-in text text editor

**Technologies used:**
- Python3
- PyQt5


**Screenshots:**
<br>
Text editor (for opening select text file and press F3 )
<br>
![New reference](/docs/images/TextEditorScreenshot.png)

