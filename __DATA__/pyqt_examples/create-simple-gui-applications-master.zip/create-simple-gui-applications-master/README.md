# create-simple-gui-applications
Create Simple GUI Applications with Python &amp; Qt
