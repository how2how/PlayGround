# 7Pez — the best/worst Unzip application ever created

Unzip your files with a cat. Drag-drop your zip file onto the floaty
cat, and fill up it's Pez-file repository. Press the head to release
the Pez (your files) into the same folder.

When you open the application the catty Pez dispenser is empty.

![Unzip](screenshot-unzip1.jpg)

Simply drag and drop your .zip file onto the cat to fill it up with Pez.

![Unzip](screenshot-unzip2.jpg)

The press the cat's head to release the Pez.

> If you think this example app is neat and want to learn more about
PyQt in general, [take a look at my ebook & online course
"Create Simple GUI Applications"](https://martinfitzpatrick.name/create-simple-gui-applications)
which covers everything you need to know to start building your own applications with PyQt.


## Code notes

### Pez

If you know anything about Pez you'll know this application has it the wrong
way around. That's because I remembered it wrong, thinking that you pressed 
the head of a Pez dispenser to make it drop Pez out the bottom.

Originally the intention was to make you press the head once for every file
you wanted to release, but that was excruciating. It's bad enough as it is.


